import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Table, TableBody, TableHead, TableHeader, TableRow, TableCell } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";

const mockStages = [
  {
    stage: "Pre-Farm",
    updated: "2024-05-01",
    ai: 3,
    sustainability: 2,
    monetization: 2,
    plugins: 3
  },
  {
    stage: "Farm/Production",
    updated: "2024-05-10",
    ai: 4,
    sustainability: 2,
    monetization: 2,
    plugins: 3
  }
];

export default function EarthWellAdminDashboard() {
  return (
    <Tabs defaultValue="overview" className="w-full">
      <TabsList className="mb-4">
        <TabsTrigger value="overview">Stage Overview</TabsTrigger>
        <TabsTrigger value="interactions">User Logs</TabsTrigger>
        <TabsTrigger value="plugins">Plugin Status</TabsTrigger>
      </TabsList>

      <TabsContent value="overview">
        <Card>
          <CardContent className="p-4">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Stage</TableHead>
                  <TableHead>Last Updated</TableHead>
                  <TableHead>AI</TableHead>
                  <TableHead>Sustainability</TableHead>
                  <TableHead>Monetization</TableHead>
                  <TableHead>Plugins</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {mockStages.map((s, i) => (
                  <TableRow key={i}>
                    <TableCell>{s.stage}</TableCell>
                    <TableCell>{s.updated}</TableCell>
                    <TableCell><Badge>{s.ai}</Badge></TableCell>
                    <TableCell><Badge variant="secondary">{s.sustainability}</Badge></TableCell>
                    <TableCell><Badge variant="outline">{s.monetization}</Badge></TableCell>
                    <TableCell><Badge>{s.plugins}</Badge></TableCell>
                    <TableCell><Button size="sm">Edit</Button></TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </TabsContent>

      <TabsContent value="interactions">
        <Card>
          <CardContent className="p-4">
            <h2 className="text-xl font-semibold mb-2">Recent User Logs</h2>
            <Input placeholder="Search logs by stage or action..." className="mb-4" />
            <p className="text-muted-foreground">(Simulated logs display goes here...)</p>
          </CardContent>
        </Card>
      </TabsContent>

      <TabsContent value="plugins">
        <Card>
          <CardContent className="p-4">
            <h2 className="text-xl font-semibold mb-2">Plugin Status</h2>
            <p className="text-muted-foreground">(Dynamic status check with API integration will be displayed here.)</p>
          </CardContent>
        </Card>
      </TabsContent>
    </Tabs>
  );
}